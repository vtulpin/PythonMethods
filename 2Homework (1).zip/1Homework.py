
import requests
from bs4 import BeautifulSoup as bs
import re
import pandas as pd

def _parser_hh(vacancy):
    vacancy_date = []
    params = {
        'text': vacancy, \
        'search_field': 'name', \
        'items_on_page': '100', \
        'page': ''
    }
    headers = {
        'User-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 YaBrowser/20.2.0.1043 Yowser/2.5 Safari/537.36'}
    main_link = 'https://hh.ru/search/vacancy'
    response = requests.get(main_link, headers=headers, params=params)
    if response.ok:
        soup = bs(response.text, 'html.parser')
        page_block = soup.find('div', {'data-qa': 'pager-block'})
        if not page_block:
            last_page = '1'
        else:
            last_page = int(page_block.find_all('a', {'class': 'HH-Pager-Control'})[-2].getText())
            for page in range(0, last_page):
                params['page'] = page
                response = requests.get(main_link, params=params, headers=headers)
                if response.ok:
                    soup = bs(response.text, 'html.parser')

                    page_block = soup.find('div', {'data-qa': 'pager-block'})
                    if not page_block:
                        last_page = '1'
                    else:
                        last_page = int(page_block.find_all('a', {'class': 'HH-Pager-Control'})[-2].getText())
                        for page in range(0, last_page):
                            params['page'] = page
                            response = requests.get(main_link, params=params, headers=headers)

                            if response.ok:
                                vacancy_items = soup.find('div', {'data-qa': 'vacancy-serp__results'}) \
                                    .find_all('div', {'class': 'vacancy-serp-item'})
                                for item in vacancy_items:
                                    vacancy_date.append(_parser_item_hh(item))

                                return vacancy_date
def _parser_item_hh(item):

    vacancy_date = {}
    vacancy_name = item.find('div', {'class': 'resume-search-item__name'}) \
        .getText() \
        .replace(u'\xa0', u' ')
    vacancy_link = item.find('div', {'class': 'resume-search-item__name'}) \
        .find('a')['href']
    vacancy_date['site'] = 'hh.ru'
    return vacancy_date


def parser_vacancy(vacancy):
    vacancy_date = []
    vacancy_date.extend(_parser_hh(vacancy))
    df = pd.DataFrame(vacancy_date)

    return df