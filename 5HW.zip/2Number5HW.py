from pprint import pprint
import re
from datetime import date
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.chrome.options import Options
from pymongo import MongoClient

chrome_options = Options()
chrome_options.add_argument('start-maximized')
driver = webdriver.Chrome(options=chrome_options)

client = MongoClient('127.0.0.1', 27017)
db = client['mails_db']
mails = db.mails


driver.get('https://mail.ru/')
login = driver.find_element_by_id('mailbox:login-input')
login.send_keys('study.ai_172@mail.ru')
driver.find_element_by_xpath("//button[@id='mailbox:submit-button']").click()
time.sleep(5)
passwr = driver.find_element_by_xpath('//input[@id="mailbox:password-input"]')
passwr.send_keys('NextPassword172')
driver.find_element_by_xpath("//input[@class='o-control']").click()
time.sleep(5)
first_leter = driver.find_element_by_class_name('llc js-tooltip-direction_letter-bottom js-letter-list-item llc_normal')
time.sleep(2)

letters = []









#passwr.send_keys(Keys.RETURN)
#time.sleep(5)


#study.ai_172@mail.ru
#NextPassword172